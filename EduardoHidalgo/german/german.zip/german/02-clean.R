colnames(german_data) <- german_clean_colnames(german_colnames)
